import React from "react";

interface layoutPropsInterface {
    children: React.ReactNode;
}

export type { layoutPropsInterface };
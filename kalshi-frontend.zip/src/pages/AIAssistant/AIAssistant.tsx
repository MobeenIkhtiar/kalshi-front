import React from 'react';

const AIAssistant: React.FC = () => {
    return (
        <div className="p-6">
            <h1 className="text-3xl font-bold text-white mb-4">AI Assistant</h1>
            <p className="text-gray-400 text-lg">We are on AI Assistant page</p>
        </div>
    );
};

export default AIAssistant;

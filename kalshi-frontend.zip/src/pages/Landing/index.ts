export { default } from './Landing';


